//var setting = require('../api/services/SettingService');
//var siteName = setting.getOne('general', 'site_name');

module.exports.custom_config = {
    general: {
        site_name : ''
    }
};